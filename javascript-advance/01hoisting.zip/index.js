// console.log(x);
// var x = 5;
// console.log(x);
var x = 5;
function run(){
    var x = 19;
    console.log(x);
}

run();

