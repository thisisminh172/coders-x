//default parameters

function greeting(name='MInh'){
    return `Hi, ${name}`;
}

console.log(greeting());