//let const
const c =12;

console.log(c)